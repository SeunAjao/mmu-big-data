from pyspark.sql import *
from pyspark.sql.functions import *

# setup spark and obtain ref to running SparkSession
spark = (SparkSession.builder.appName("words").getOrCreate())

# read from given file in current directory
input = spark.read.text("./t8.shakespeare.txt")
input.show()
#input.select(explode(split(input.value, " ")).alias("w")
words = input.select(explode(split(input.value, " ")).alias("w"))
words.groupBy("w").count().orderBy("count", ascending=False).show(20)
